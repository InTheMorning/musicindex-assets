# MUSIC INDEX — Visual Brand Spec

Companion to `MUSICINDEX_BRAND.md`. This file covers the visual side: logo construction, color, typography, and application rules.

---

## 1 · The mark

The mark is **three asymmetric structures on a flat baseline**. It is intentionally not a symmetric figure: each structure has a different height and a different angled-edge configuration. The shapes read together as a stylized M and as a structural index of three vertical elements.

The mark is **not letters**. It is structure. Color is optional; geometry is the brand.

### Construction grid

The mark is drawn on a **1000 × 1000** unit grid with a flat baseline at `y = 841` and 132–160 unit padding around the bounding box.

**LEFT structure** — pentagon, 5 vertices.
A short rectangular column with a small flat top and an angled top-right corner (chamfer).

| # | x | y | Description |
|---|---|---|---|
| 1 | 132 | 274 | Top-left apex (start of flat top) |
| 2 | 177 | 274 | Right end of small flat top |
| 3 | 249 | 304 | End of top-right diagonal (start of vertical right edge) |
| 4 | 249 | 841 | Bottom-right |
| 5 | 132 | 841 | Bottom-left |

**MIDDLE structure** — inverted-U, 9 vertices.
The tallest of the three. Two vertical legs connected at the top by an angled "roof" — the outer top diagonal and the inner top diagonal both slope down-right.

| # | x | y | Description |
|---|---|---|---|
| 1 | 339 | 160 | Top-left apex (start of flat top) |
| 2 | 489 | 160 | End of flat top |
| 3 | 657 | 280 | End of outer top-right diagonal |
| 4 | 657 | 841 | Bottom-right of right leg |
| 5 | 546 | 841 | Bottom-left of right leg (entrance to inner gap) |
| 6 | 546 | 388 | Top-right of inner gap (right leg's inner top) |
| 7 | 456 | 331 | Top-left of inner gap (left leg's inner top) — angled diagonal up-left |
| 8 | 456 | 841 | Bottom-right of left leg (inner side) |
| 9 | 339 | 841 | Bottom-left |

**RIGHT structure** — hexagon, 6 vertices.
Tall narrow shape with an angled top-left corner *and* an angled bottom-right corner — gives it a parallelogram-like lean.

| # | x | y | Description |
|---|---|---|---|
| 1 | 867 | 250 | Top-right (right end of small flat top) |
| 2 | 867 | 790 | Start of bottom-right diagonal |
| 3 | 759 | 841 | End of bottom-right diagonal (right end of small flat bottom) |
| 4 | 750 | 841 | Bottom-left |
| 5 | 750 | 304 | End of top-left diagonal (top of vertical left edge) |
| 6 | 858 | 250 | Left end of small flat top |

### Path data (canonical SVG)

```svg
<svg viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg" fill="none">
  <!-- LEFT pentagon -->
  <path d="M 132 274 L 177 274 L 249 304 L 249 841 L 132 841 Z"/>
  <!-- MIDDLE inverted-U -->
  <path d="M 339 160 L 489 160 L 657 280 L 657 841 L 546 841 L 546 388 L 456 331 L 456 841 L 339 841 Z"/>
  <!-- RIGHT hexagon -->
  <path d="M 867 250 L 867 790 L 759 841 L 750 841 L 750 304 L 858 250 Z"/>
</svg>
```

### Drawing rules

- **All baselines align.** All three structures sit on `y = 841`.
- **All vertical edges are perfectly vertical.** No structure leans; the lean comes from the angled top/bottom cuts.
- **Angles are intentional.** Do not "balance" the asymmetry by mirroring shapes or normalizing heights. The asymmetry is the design.
- **Spacing is fixed.** Gap between LEFT (right edge x=249) and MIDDLE-left-leg (x=339) is 90. Gap between MIDDLE-right-leg (x=657) and RIGHT (x=750) is 93. Do not adjust.
- **The middle's inner gap is a structural feature, not a hole.** Render as a single closed path, not as two paths with a punched-out region.

### Clear space

Reserve a clear-space buffer equal to **the LEFT structure's full width** (117 grid units) on all sides of the mark's bounding box. Nothing — text, images, edges, other marks — enters this buffer.

### Minimum sizes

- **Digital:** 32 px tall (the asymmetric details and the inner gap of the middle become illegible below this). Below 32 px, switch to a single solid square mark.
- **Print:** 10 mm tall.
- **Favicon:** the mark on a solid `#0D0D0D` square, 48 × 48 minimum. Pad so the mark's bounding box occupies ≤ 70 % of the favicon area.

### Don'ts

- Do not rotate, skew, italicize, or shear.
- Do not mirror or "fix" the asymmetry.
- Do not gradient-fill.
- Do not add stroke.
- Do not separate the three structures into different colors.
- Do not fill the inner gap of the middle structure.
- Do not place on photographic backgrounds without an underlying solid panel.

---

## 2 · Lockups

Three official lockups. Pick one and stay with it within a given surface.

| Lockup | When to use | Aspect |
|---|---|---|
| **Primary** (mark + MUSIC / INDEX stacked, two-line wordmark right of mark) | Default. Marketing, decks, hero blocks. | ~2.6 : 1 |
| **Horizontal** (mark + MUSIC INDEX inline) | Wide bars, footers, banners, email signatures. | ~4.7 : 1 |
| **Stacked** (mark above, MUSIC / INDEX below) | Square, portrait, social avatars, apparel, flags, vinyl labels. | ~1 : 1.4 |

### Lockup spacing

Mark sits in its 1000 × 1000 box. Wordmark begins **100 grid units** to the right of the mark's canvas edge (i.e., at `x = 1100` in lockup viewBox).

### Wordmark proportions

- Cap-height is **45 %** of mark height in the primary lockup, **55 %** in the horizontal lockup, and **30 %** in the stacked lockup.
- Letter-spacing: default Inter Bold tracking (no override).
- Set in **caps**. Sentence case is reserved for body copy.

---

## 3 · Color

### Palette

| Token | Hex | Role |
|---|---|---|
| `ink` | `#0D0D0D` | Primary background. Mark surface. |
| `paper` | `#F2F2F2` | Mark on dark backgrounds. Body text on dark. |
| `signal-orange` | `#FF5A00` | Accent. Headings. Hover states. The default chromatic accent. |
| `signal-purple` | `#7B5CFF` | Accent. Editorial / cultural surfaces. |
| `signal-lime` | `#C7FF00` | Accent. Developer / code surfaces. |
| `signal-blue` | `#2D7BFF` | Accent. System / status surfaces. |

### Default mode: **monochrome**

The brand is monochrome-first. The mark in `paper` on `ink` (or `ink` on `paper`) is the canonical presentation. Color is used as a single, decisive accent — never as decoration.

### Color usage rules

- **One accent per surface.** Never mix two signal colors.
- The **mark may be set in any palette color**, but the chosen color must also tint the wordmark in the same lockup. They move together — never split colors.
- Body text is `paper` on `ink`, or `ink` on `paper`. Never on a signal color.
- Signal colors meet WCAG AA against `ink` (≥ 4.5 : 1) for body text. Verify against `paper` per surface.

### When to reach for which color

| Color | Use for |
|---|---|
| Orange | Default accent. Calls to action. Headlines on dark. |
| Purple | Editorial pages, artist features, longform writing, scene coverage. |
| Lime | Developer documentation, code blocks, system messages. |
| Blue | Status, links, secondary navigation, calmer surfaces. |

---

## 4 · Typography

**Primary typeface: Inter** — Medium / Semi Bold / Bold.

| Use | Weight | Case | Tracking |
|---|---|---|---|
| Wordmark | Bold (700) | UPPERCASE | Default |
| Display headlines | Bold (700) | Sentence case | -0.02em |
| Subheads | Semi Bold (600) | Sentence case | -0.01em |
| Body | Medium (500) | Sentence case | 0 |
| Labels / metadata | Medium (500) | UPPERCASE | 0.08em |
| Code | Mono (JetBrains Mono or Berkeley Mono) | as written | 0 |

### Typographic rules

- Sentence case for headlines. Title Case is forbidden in product copy.
- ALL CAPS only for the wordmark, eyebrows / labels, and acknowledged acronyms.
- Numerals: tabular for tables and lists, proportional for prose.
- No italic for emphasis — use weight (Semi Bold) instead. Italic is reserved for titles of works (album names, song names).

---

## 5 · File deliverables

```
musicindex/
├── MUSICINDEX_BRAND.md                       ← LLM voice / copy guide
├── SPEC.md                                   ← This file
├── README.md                                 ← What's in the pack
├── musicindex-mark.svg                       ← Master mark, monochrome paper
├── musicindex-mark-white.svg                 ← Same as above, explicit name
├── musicindex-mark-black.svg                 ← Mark in ink (for light backgrounds)
├── musicindex-mark-orange.svg                ← Mark in signal-orange
├── musicindex-mark-purple.svg                ← Mark in signal-purple
├── musicindex-mark-lime.svg                  ← Mark in signal-lime
├── musicindex-mark-blue.svg                  ← Mark in signal-blue
├── musicindex-lockup-primary.svg             ← Primary lockup, paper on transparent
├── musicindex-lockup-primary-black.svg       ← Primary lockup, ink on transparent
├── musicindex-lockup-horizontal.svg          ← Horizontal lockup
├── musicindex-lockup-stacked.svg             ← Stacked lockup
└── musicindex-brand-overview.png             ← One-page visual summary
```

All SVGs are flat-fill paths with no stroke, no gradient, no filter. Mark uses the path data in §1. Wordmarks in lockups are converted to outlines so files render identically without Inter installed.

---

## 6 · Application rules

### App icon

Mark only (no wordmark). Centered on `#0D0D0D` square. Mark fills 65 % of the icon's shorter side. Apply a 22.4 % corner radius (iOS continuous curve standard) on the icon canvas — do **not** round the mark itself.

### Splash / launch

Stacked lockup centered on `#0D0D0D`. Wordmark in `paper`. No tagline.

### Social avatars

Mark only on `#0D0D0D`. Padding: one LEFT-structure width on every side.

### Stage / large-format

Mark only on `#0D0D0D`. Mark scales to 30–40 % of canvas height. Color of mark may be a signal color when paired with content.

### Vinyl label

Stacked lockup centered. Side identifier (A / B) and BPM in `paper` mono small caps at top and bottom of the label respectively. No additional decoration.

### Hardware (synth, controller, interface)

Mark only, screened or etched in `paper` or `ink` depending on chassis. Position bottom-left or top-right of front panel. Wordmark optional, set very small in caps below or beside the mark.

### Apparel

Stacked or horizontal lockup. Centered chest or left chest. `paper` on `ink` garment, or `ink` on natural-tone garment. No signal-color print on apparel.

### Document templates

Horizontal lockup top-left of cover, mark only top-left of interior pages. Footer: small caps eyebrow `MUSIC INDEX · SECTION TITLE · PAGE N`.
