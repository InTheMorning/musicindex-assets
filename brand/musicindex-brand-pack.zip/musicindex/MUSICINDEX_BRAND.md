# MUSIC INDEX — Brand Voice & Copy Guide

> **For LLMs:** This file is the operating manual. Drop it into your system context and any copy you generate for Music Index — homepage, docs, errors, social, emails, captions, alt text — should follow it. When uncertain, prefer plain over clever, specific over abstract, present tense over future, "we maintain" over "we believe."

---

## 1 · What Music Index is

Music Index is open infrastructure for music — an index of artists, releases, and feeds, plus the APIs and libraries needed to build apps on top of it. Artists submit their feeds to be listed and discovered. Developers use the spec and SDKs to build players, catalogs, players, and tools. The project is the music equivalent of Podcast Index for podcasting.

It is not a streaming service, not a label, not a marketplace, not a social network. It is a public utility: a catalog and a spec.

---

## 2 · Audience

Two primary readers, balanced equally:

- **Developers** building music apps — they want a trustworthy spec, working SDKs, and predictable APIs. They decide whether the project gets traction.
- **Artists and curators** submitting feeds — they want to be listed in a credible, neutral catalog without giving up rights or paying rent.

A third audience reads occasionally: journalists, researchers, and grant reviewers who care that something open exists.

Copy should be useful to all three without code-switching. Avoid copy that sounds written *for* one of them and *about* the others.

---

## 3 · Archetype

**Primary: Steward.** Music Index is held for the community, not extracted from it. Custodial, not custodial-passive — we maintain because we ship.

**Secondary: Builder.** We build the alternative rather than perform protest of the status quo. The spec, the SDKs, the namespace, the host: all Builder.

**Flavoring: Sage.** Taxonomy and neutral listing show up naturally in the work. Don't lean on Sage as a posture — never adopt a "we know best" register.

**Avoid:** Hero ("the future of music"), Magician ("reimagining how artists connect"), Lover ("the soul of every song"), Outlaw-as-performance (manifestos against streaming). These poisons all make the project sound like a startup pitch.

---

## 4 · Brand tones — what each tone means in copy

| Tone | Meaning | Copy implication |
|---|---|---|
| **Foundational** | Built on structure. Dependable. Future-ready. | Mention concrete primitives: feeds, namespace, spec, endpoints. Use the present tense. |
| **Confident** | Clear in purpose. No noise, all signal. | One claim per sentence. No hedging modifiers ("we hope to," "we aim to"). State what is. |
| **Cultural** | Rooted in music. Connected to people and scene. | Reference real artists, scenes, formats, and music vocabulary fluently — but never decoratively. |
| **Modern** | Minimal and forward-looking. Always evolving. | Spare punctuation. No exclamation marks. Sans-serif voice — clean, no flourishes. |
| **Bold** | Unapologetic. Makes space. Leads change. | State the position directly. Don't ask permission. Don't soften. Don't disclaim. |

---

## 5 · Tone of voice principles — what each principle does

| Principle | Statement | What it produces |
|---|---|---|
| **Intentional** | We build with purpose. | Every sentence earns its space. If a line could be deleted without loss, delete it. |
| **Essential** | We remove what doesn't matter. | Strip qualifiers. "An open API" not "a robust, comprehensive, fully-featured open API." |
| **Collective** | We grow together. | "We" and "the index" rather than "I" or "the platform." Credit contributors in plural. |
| **Open** | We create access and opportunity. | Link to spec, repo, and feed submission visibly. Never gate basic information. |
| **Progressive** | We move music forward. | Frame the work as ongoing infrastructure, not a launched product. |

---

## 6 · Voice rules — DO and DON'T

### DO

- Write in present tense. *"Music Index hosts public feeds."* not *"will host"* or *"is going to host."*
- Use active voice with a clear subject. *"We publish the spec."* not *"The spec is published."*
- Lead with the noun, not the adjective. *"An open API for music catalogs."* not *"A revolutionary new approach to..."*
- Name concrete primitives when they exist: *feed, namespace, endpoint, GUID, format, spec, SDK, registry.*
- Keep sentences short. One idea per sentence. Vary length only to control rhythm.
- Use the Oxford comma. Sentence case for headlines. ALL CAPS only for the wordmark.
- Cite the alternative by building it, not naming it. *"Self-host your catalog."* not *"Don't get locked into Spotify."*

### DON'T

- No hype verbs: *unleash, empower, revolutionize, transform, reimagine, supercharge, disrupt, democratize.*
- No music-blog purple: *the soul of music, the heartbeat of culture, where artists thrive, sonic landscape, journey through sound.*
- No startup-future: *the future of X, the new way to Y, X reimagined.*
- No vague benefits: *seamless, intuitive, beautiful, powerful, robust, comprehensive, world-class.*
- No fake urgency: *now, today, finally, at last, get started in seconds.*
- No exclamation marks. No emoji in product copy. No em dash decoration where a period works.
- No second-person flattery: *creators like you, the artists who make this possible.*
- No manifesto mode. The position is in the work, not the prose.

---

## 7 · Lexicon

### Prefer

| Use | Instead of |
|---|---|
| index | catalog (when speaking generally — "the catalog" is fine for *a* catalog) |
| feed | profile, page |
| publish, host, list | upload, post, share |
| artist, label, curator | creator, content owner, rights holder |
| open | free, accessible, democratic |
| spec, schema | standard, framework |
| build on | integrate with, leverage |
| self-host | own your data |
| submit your feed | join the platform |
| listed | featured, showcased |

### Forbidden

*revolutionary, game-changing, cutting-edge, next-generation, world-class, best-in-class, seamless, frictionless, intuitive, powerful, robust, scalable solution, unique value proposition, journey, ecosystem (use "infrastructure"), space (use "category"), creators (use "artists" or "people"), thrive, unlock, supercharge, level up, stack, vibe, drops (as a verb for releases — except in a direct artist quote).*

---

## 8 · Sentence patterns

These are the building blocks. Most on-brand copy can be assembled from them.

1. **Definitional** — *"Music Index is [noun]. It [verb] [object]."*
   *Music Index is an open catalog of music. It hosts feeds and exposes them through a public API.*

2. **Action declaration** — *"We [verb] [object]."*
   *We maintain the spec. We host the registry. We publish a Swift SDK and a Rust client.*

3. **Capability** — *"[Subject] [verb] [object] via [interface]."*
   *Apps query the index via a JSON API. Artists submit feeds via a hosted form or a self-hosted RSS endpoint.*

4. **Anti-claim by contrast** — *"[What we are]. Not [what we aren't]."*
   *An index. Not a store. Not a platform. Not a label.*

5. **Spec callout** — *"See `[spec/file/endpoint]` for [thing]."*
   *See `feed.xml` for the schema. See `/v1/artists` for the API reference.*

Avoid the question-headline pattern (*Tired of streaming royalties?*), the empty-promise pattern (*Music, reimagined.*), and the listicle pattern (*5 reasons artists love Music Index*).

---

## 9 · Length guide by surface

| Surface | Length | Example |
|---|---|---|
| Wordmark | 2 words | `MUSIC INDEX` |
| Tagline | ≤ 6 words | *Open infrastructure for music.* |
| Hero subhead | 1 sentence, ≤ 20 words | *An open catalog of artists, releases, and feeds — with the APIs and libraries to build on top.* |
| Section header | 2–4 words | *For developers / For artists / The spec* |
| Section body | 2–4 sentences | First sentence states the function. Following sentences add specifics — endpoint, format, link. |
| Button | 1–3 words, verb-led | *Submit a feed / Read the spec / Browse the index* |
| Empty state | 1 sentence | *No feeds yet. Submit one to start.* |
| Error message | 1 sentence, plus a fix | *Feed URL didn't validate. Check that the endpoint returns RSS or Atom XML.* |
| 404 | 1 sentence | *That page isn't in the index.* |
| Social post | ≤ 2 short sentences, no emoji | *We added pagination cursors to the artists endpoint. Clients should switch to `?cursor=` over the next 90 days.* |

---

## 10 · Worked examples

### Homepage hero

> # Open infrastructure for music.
> An index of artists, releases, and feeds — with the APIs and libraries to build on top.
>
> [ Read the spec ]   [ Submit a feed ]

### About page — first paragraph

> Music Index is a public catalog of music. It hosts artist feeds, publishes a feed schema, and exposes everything through a versioned API. Apps can build on it. Artists can list themselves on it. No one owns it.

### For developers — page intro

> The Music Index API gives you typed access to every published feed. Endpoints are versioned, paginated, and rate-limited. Clients exist for Swift, Rust, TypeScript, and Python. The full schema lives in `feed.xml`.

### For artists — page intro

> Submit your feed to be listed. Music Index hosts the link, not the audio. You keep your files where you keep them today, on your site or on whatever host you trust. Listings are free and remain free.

### API docs — endpoint description

> ### `GET /v1/artists/{guid}`
> Returns the artist record for a given GUID. Includes feed URL, last-checked timestamp, and a list of releases. Cached for 60 seconds.

### Error message

> Feed URL didn't validate. Music Index expects RSS 2.0 or Atom 1.0 with a `music:` namespace declaration. See the spec for the minimum required fields.

### 404 page

> ## That page isn't in the index.
> The link may have moved. Browse the index or read the spec.

### Social — release announcement

> Pagination cursors are now available on `/v1/artists` and `/v1/releases`. Offset-based pagination remains supported through the next minor version. Clients should switch over by 1.4.

### Social — community update

> Three new SDKs landed this week: a Kotlin client from @[contributor], a Go client from @[contributor], and a CLI from @[contributor]. Full list in the README.

### Email subject lines

- *Music Index 1.3 is out*
- *New: artist verification flow*
- *Spec change: `music:` namespace v2 draft*

### Newsletter intro paragraph

> A short note this month: the namespace draft for v2 is open for review, three SDKs landed, and 412 new feeds were added. Details below.

### Job posting intro

> Music Index maintains the open catalog and spec. We're hiring a backend engineer to work on the registry and the public API. The work is mostly Rust, occasionally Python, and the codebase is open-source.

### Press / one-liner for journalists

> Music Index is an open, public catalog of music — the music equivalent of Podcast Index. Artists submit feeds. Developers build on the spec.

---

## 11 · Surface-specific notes

- **API documentation** — Lead with the endpoint signature. Sentence case for prose. Code samples in a `request → response` order. Never apologize for technical detail.
- **Artist-facing pages** — Use plainer words but keep the same posture. Don't switch to marketing voice. Concrete benefits ("listings are free and remain free") beat abstract benefits ("artist-first values").
- **Error messages** — Always state what failed and what to try. Never apologize ("we're sorry"). Never blame the user.
- **Empty states** — One sentence + one action. Never funny.
- **Social** — Treat the timeline like changelog notes. If there's nothing concrete to say, don't post.
- **Press** — One sentence definition + one sentence comparison + one link.

---

## 12 · Self-check — is this on-brand?

Run any draft through these questions. If the answer to two or more is *no*, rewrite.

1. Is every sentence concrete? (Names a thing, action, format, or endpoint.)
2. Could a developer and an artist both read this without flinching?
3. Have I used present tense and active voice?
4. Have I avoided the forbidden words in §7?
5. Would deleting this sentence cost the reader anything? (If no, delete it.)
6. Does this sound like a public utility, or like a startup pitch?
7. Is the position carried by what we do, not by what we say about ourselves?

If the draft passes all seven, ship it.

---

## 13 · Quick-reference card

```
NAME           Music Index
WHAT           Open catalog + API + spec for music
ARCHETYPE      Steward + Builder (Sage flavoring)
TONE           Foundational · Confident · Cultural · Modern · Bold
TOV            Intentional · Essential · Collective · Open · Progressive
DEFAULT VOICE  Plain. Concrete. Present tense. Active. Short.
NEVER          Hype verbs. Music-blog purple. Manifesto mode. Exclamation marks.
PARALLEL       What Podcast Index is to podcasts.
```
