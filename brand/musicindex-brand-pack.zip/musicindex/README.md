# Music Index — Brand Pack

This pack contains everything needed to put Music Index in the world: the logo (in every variant), the visual rules, and a drop-in copy guide for LLMs.

## What's inside

| File | What it is |
|---|---|
| `MUSICINDEX_BRAND.md` | **The LLM voice guide.** Drop this into any LLM context to generate on-brand copy. |
| `SPEC.md` | The visual brand spec — logo construction, color, typography, lockups, application rules. |
| `musicindex-mark*.svg` | The mark on its own, in every palette color. Master geometry: `viewBox 0 0 800 800`, transparent background. |
| `musicindex-lockup-*.svg` | The three official lockups (primary, horizontal, stacked) with the wordmark outlined to paths. |
| `musicindex-brand-overview.png` | A one-page visual summary you can drop into a deck or a brief. |

## Quick start

**To generate copy with an LLM:** Open `MUSICINDEX_BRAND.md`, copy its contents into your system prompt or Claude project's instructions, then ask for the copy you need.

**To use the logo:** Pick a lockup from `SPEC.md § 2`, drop in the corresponding SVG, and respect the clear-space rule.

**To design something new (a page, a poster, a deck):** Skim `SPEC.md` first. The default state is monochrome on `#0D0D0D`. Reach for one signal color per surface.

## License

The voice and visual system are Music Index's. Inter is licensed under the SIL Open Font License.
